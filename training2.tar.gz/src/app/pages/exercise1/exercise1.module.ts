import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Exercise1Component } from './exercise1.component';



@NgModule({
  declarations: [
    Exercise1Component,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild([
      {
        path: '',
        component: Exercise1Component
      }
    ])
  ]
})
export class Exercise1Module { }
