import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exercise',
  templateUrl: './exercise.component.html',
  styleUrls: ['./exercise.component.css']
})
export class ExerciseComponent implements OnInit {

  e = [
    {
      nama: 'Dzurrahman',
      umur: 23,
      status: false
    },
    {
      nama: 'Roki',
      umur: 26,
      status: true
    }
  ]

  constructor() { }

  ngOnInit(): void {
  }

}
