export const environment = {
  production: true,
  base_api: 'http://localhost:3000/prod'
};
